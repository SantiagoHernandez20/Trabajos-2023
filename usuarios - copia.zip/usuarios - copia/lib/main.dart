import 'package:flutter/material.dart';
import 'package:usuarios/view/strapi_app.dart';

void Main() async {
  runApp(const Strapi());
}
