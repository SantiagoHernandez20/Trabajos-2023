import 'package:flutter/material.dart';

//Creacion de clase que contendra las variables que necesitemos para el texfield
class Textfield extends StatelessWidget {
  //variables
  final String hintText;
  final TextStyle hinStyle;
  final Icon icon;
  final TextDirection textDirection;
  final TextEditingController controller;
  final void Function(String)? onChanged;

  const Textfield({
    super.key,
    required this.hinStyle,
    required this.hintText,
    required this.icon,
    required this.controller,
    required this.onChanged,
    required this.textDirection,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 70,
      child: TextFormField(
        onChanged: onChanged,
        controller: controller,
        textDirection: textDirection,
        decoration: InputDecoration(
          fillColor: const Color(0xffFFFFFF),
          filled: true,
          hintText: hintText,
          hintStyle: hinStyle,
          suffixIcon: icon,
          contentPadding: const EdgeInsets.only(top: 10, bottom: 10, left: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4.0),
            borderSide: const BorderSide(
              color: Color(0xffDEDEDF),
            ),
          ),
          enabledBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xffEBEBEC))),
        ),
      ),
    );
  }
}
