//Creamos clases Users para gestionar datos de usuarios
class Users {
  int id;
  String name;
  String email;
  String password;

  Users(
    this.id,
    this.name,
    this.email,
    this.password,
  );
}
