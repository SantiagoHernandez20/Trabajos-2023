import 'package:flutter/material.dart';
import 'package:usuarios/customisation/text_field.dart';
import 'package:usuarios/view/show_users.dart';
import 'package:http/http.dart' as http;
import 'package:usuarios/view/user.dart';
import 'dart:convert';
import 'dart:async';

//clase que permite crear nuevos usuarios mediante el uso de la API STRAPI

class CreateUser extends StatefulWidget {
  final int? id;
  const CreateUser({super.key, this.id});

  @override
  State<CreateUser> createState() => _CreateUser();
}

Users users = Users(0, '', '', '');

class _CreateUser extends State<CreateUser> {
  final TextEditingController _nameController =
      TextEditingController(text: users.name);
  final TextEditingController _emailController =
      TextEditingController(text: users.email);
  final TextEditingController _passwordController =
      TextEditingController(text: users.password);

  @override
  void dispose() {
    super.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
  }

  Future save() async {
    const String url = "http://localhost:65400/api/usuarios";

    final Map<String, String> dataHeader = {
      'content-Type': 'application/json; charset=UTF-8',
    };
    final Map<String, dynamic> dataBody = {
      "name": users.name,
      "email": users.email,
      "password": users.password
    };

    await http.post(
      Uri.parse(url),
      headers: dataHeader,
      body: json.encode({'data': dataBody}),
    );

    Navigator.pushAndRemoveUntil<void>(
        context,
        MaterialPageRoute<void>(
                builder: (BuildContext context) => const DisplayUsers())
            as Route<void>,
        (Route<dynamic> route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo[700],
        elevation: 0.0,
        title: const Text('Create User'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding:
              const EdgeInsets.only(top: 100, bottom: 100, left: 18, right: 18),
          child: Container(
            height: 550,
            width: 400,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: Colors.indigo[700],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 300,
                  decoration: const BoxDecoration(boxShadow: []),
                  child: TextField(
                    controller: _nameController,
                    onChanged: (val) {
                      users.name = val;
                    },
                    textDirection: TextDirection.ltr,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
