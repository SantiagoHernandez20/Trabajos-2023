package com.example.usuarios

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
